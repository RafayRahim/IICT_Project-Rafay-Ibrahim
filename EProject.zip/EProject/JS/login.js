document.getElementById("btn").onclick = function(){
    location.href = "signup.html";
}