function querysend(){
    alert("Your Query Has Been Sent. \n Kindly Wait For The Response.");
}