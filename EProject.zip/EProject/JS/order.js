function ordersend(){
    alert("Your Order Has Been Submitted. \nKindly Wait For The Confirmation.");
}